## Version 1.0.0 (4 aug 2019)
- Initial template
- Bootstrap version 3.3.7

## Version 1.0.1 (11 oct 2019)
- Modified preloader for all browser support